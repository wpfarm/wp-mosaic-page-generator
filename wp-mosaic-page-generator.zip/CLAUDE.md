# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a WordPress plugin called "WP Mosaic Page Generator" (version 2.3.2) that enables bulk page creation with dynamic content import from CSV/JSON files. The plugin is developed by Direction.com and requires a subscription for premium features.

## Architecture

### Core Structure
- **Entry Point**: `index.php` - Main plugin file with activation hooks
- **Loader**: `loader.php` - Loads all required classes 
- **Main Class**: `classes/class.php` - Contains `WpMosaicPageGenerator` class extending `wpmpgCommon`
- **Base Class**: `classes/common.php` - Contains `wpmpgCommon` with shared utilities
- **Admin Interface**: `admin/tabs/` - Contains all admin panel tabs and UI

### Key Classes
- `WpMosaicPageGenerator` (classes/class.php) - Main plugin functionality with RankMath SEO integration
- `wpmpgCommon` (classes/common.php) - Base class with utility functions
- `wpmpgPostType` (classes/postype.php) - Custom post type management
- `wpmpgTaxoTerm` (classes/taxoterm.php) - Taxonomy and term handling
- `wpmpgElementorCPF` (classes/elementor-cpf.php) - Elementor integration for custom fields

### Admin Panel Structure
- `admin/tabs/main.php` - Main upload and processing interface
- `admin/tabs/cpt.php` - Custom post type management
- `admin/tabs/cpt-cpf.php` - Custom post fields management
- `admin/tabs/settings.php` - Plugin settings
- `admin/tabs/help.php` - Help documentation

### Plugin Constants
- `wpmpg_url` - Plugin directory URL
- `wpmpg_path` - Plugin directory path
- `WPMPG_UPLOAD_FOLDER` - Upload folder name ('mosaicpagegenerator')

## Development Commands

This is a WordPress plugin with no build process - it runs directly as PHP code. No npm, composer, or build tools are configured.

### WordPress Plugin Development
- Plugin files are loaded via WordPress hooks system
- No compilation or build steps required
- JavaScript and CSS files are in `js/` and `css/` directories respectively
- Uses WordPress coding standards and hooks

### Testing
- No automated test framework is configured
- Testing should be done in WordPress environment
- Plugin requires WordPress 3.0.1+ and is tested up to WordPress 6.6

## Key Features
- Bulk page generation from CSV/JSON imports
- Custom post type and taxonomy creation
- RankMath SEO integration for score calculation
- Elementor page builder integration
- File upload handling via Plupload (vendors/plupload/)
- Dynamic content templating with placeholders

## WordPress Integration
- Follows WordPress plugin architecture
- Uses WordPress hooks and filters system
- Integrates with popular plugins (RankMath, Elementor)
- Supports multisite installations