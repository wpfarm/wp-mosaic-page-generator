<?php
/**
 * Simple test runner for WPMPG QA testing
 * 
 * This file provides utilities for running automated tests
 * during development and QA processes.
 */

if (!defined('ABSPATH')) {
    die('Direct access not permitted');
}

class WpmpgTestRunner {
    
    public static function run_basic_tests() {
        wpmpgCommon::debug_log("Starting basic test suite", null, "INFO");
        
        self::test_logging_system();
        self::test_csv_parsing();
        self::test_security_functions();
        
        wpmpgCommon::debug_log("Basic test suite completed", null, "INFO");
    }
    
    public static function test_logging_system() {
        wpmpgCommon::debug_log("Testing logging system", null, "INFO");
        wpmpgCommon::security_log("Test security log entry", ["test" => "data"]);
        
        $start_time = microtime(true);
        $memory_before = memory_get_usage();
        
        // Simulate some work
        usleep(1000);
        
        wpmpgCommon::performance_log("Test operation", $start_time, $memory_before);
    }
    
    public static function test_csv_parsing() {
        wpmpgCommon::debug_log("Testing CSV parsing functionality", null, "INFO");
        
        $test_files = [
            'test-small.csv',
            'test-malformed.csv',
            'sample-data.csv'
        ];
        
        foreach ($test_files as $file) {
            $file_path = plugin_dir_path(__FILE__) . $file;
            if (file_exists($file_path)) {
                wpmpgCommon::debug_log("Found test file: {$file}", null, "INFO");
                // Add actual CSV parsing test logic here
            } else {
                wpmpgCommon::debug_log("Missing test file: {$file}", null, "WARNING");
            }
        }
    }
    
    public static function test_security_functions() {
        wpmpgCommon::debug_log("Testing security functions", null, "SECURITY");
        
        // Test nonce creation
        $nonce = wp_create_nonce('wpmpg_test_action');
        wpmpgCommon::security_log("Created test nonce", ["nonce" => $nonce]);
        
        // Test input sanitization
        $test_inputs = [
            '<script>alert("xss")</script>',
            "'; DROP TABLE wp_posts; --",
            '../../../etc/passwd',
            'normal input'
        ];
        
        foreach ($test_inputs as $input) {
            $sanitized = sanitize_text_field($input);
            wpmpgCommon::security_log("Input sanitization test", [
                'original' => $input,
                'sanitized' => $sanitized
            ]);
        }
    }
    
    public static function generate_test_report() {
        $upload_dir = wp_upload_dir();
        $log_file = $upload_dir['basedir'] . '/wpmpg-debug.log';
        
        if (file_exists($log_file)) {
            $log_content = file_get_contents($log_file);
            $lines = explode("\n", $log_content);
            
            $report = [
                'total_entries' => count($lines),
                'security_entries' => count(array_filter($lines, function($line) {
                    return strpos($line, 'SECURITY') !== false;
                })),
                'error_entries' => count(array_filter($lines, function($line) {
                    return strpos($line, 'ERROR') !== false;
                })),
                'performance_entries' => count(array_filter($lines, function($line) {
                    return strpos($line, 'PERFORMANCE') !== false;
                }))
            ];
            
            wpmpgCommon::debug_log("Test report generated", $report, "INFO");
            return $report;
        }
        
        return null;
    }
}

// Auto-run tests if in dev mode
if (defined('WPMPG_DEV_MODE') && WPMPG_DEV_MODE && defined('WPMPG_DEBUG') && WPMPG_DEBUG) {
    add_action('admin_init', function() {
        if (isset($_GET['wpmpg_run_tests']) && current_user_can('manage_options')) {
            WpmpgTestRunner::run_basic_tests();
            wp_redirect(admin_url('admin.php?page=wpmpg&test_results=1'));
            exit;
        }
    });
}