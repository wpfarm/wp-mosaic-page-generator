# QA Testing Environment

This directory contains test files and utilities for development and QA testing.

## Test Files

- `sample-data.csv` - Sample location data for general testing
- `test-small.csv` - Small dataset (10 rows) for quick testing
- `test-large.csv` - Large dataset (100+ rows) for performance testing
- `test-malformed.csv` - Invalid/malformed data for error handling testing
- `test-security.csv` - Data with potential security issues for security testing

## Usage

1. Enable development mode in `wp-config.php`:
   ```php
   define('WPMPG_DEBUG', true);
   define('WPMPG_DEV_MODE', true);
   ```

2. Upload test CSV files through the plugin interface
3. Monitor logs in WordPress debug.log
4. Check console for security validation messages

## Security Testing

Test cases include:
- Nonce verification
- Input sanitization
- File upload restrictions
- Privilege escalation
- SQL injection attempts
- XSS attempts

**DO NOT use these files in production environments.**