<?php
/**
 * Development Configuration for WP Mosaic Page Generator
 * 
 * Add these constants to your wp-config.php for development/QA testing:
 */

// Enable WordPress debug logging
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);

// WPMPG Debug and Development Constants
define('WPMPG_DEBUG', true);           // Enable plugin debug logging
define('WPMPG_DEV_MODE', true);        // Enable development features
define('WPMPG_TEST_DATA', true);       // Use test data instead of production

// Security testing constants
define('WPMPG_BYPASS_NONCE', false);   // Set to true ONLY for nonce testing
define('WPMPG_LOG_SECURITY', true);    // Log all security-related actions
define('WPMPG_STRICT_MODE', true);     // Enable strict security validation

// Performance testing
define('WPMPG_LOG_PERFORMANCE', true); // Log performance metrics
define('WPMPG_MEMORY_LIMIT', '256M');  // Override memory limit for testing

/**
 * Usage Examples:
 * 
 * 1. Basic development setup:
 *    define('WPMPG_DEBUG', true);
 *    define('WPMPG_DEV_MODE', true);
 * 
 * 2. Security testing:
 *    define('WPMPG_LOG_SECURITY', true);
 *    define('WPMPG_STRICT_MODE', true);
 * 
 * 3. Performance testing:
 *    define('WPMPG_LOG_PERFORMANCE', true);
 *    define('WPMPG_MEMORY_LIMIT', '512M');
 */