var $ = jQuery;
let rtime = 6000;
let mmrunningstatus_mosaic = 1;
let time = 0;
let interval;
jQuery(document).ready(function($) {
    "use strict";     
    $(document).on("click", ".act_way_to_upload", function() {      
        var selected_step =  $(this).attr("selected-opt");  
        var _sel_val =$(this).val();                        
    });     
    
    $(document).on("click", "#wmp-btn-submit", function() {   
        $("#wmp-form").submit();               
    });

    $(document).on("click", "#wmp-btn-start-import-submit", function() {  
        $("#step").val('3');                  
        ms_build_links_array();
    });

    $(document).on("click", ".wpmpg-int-delete-acc", function(e) {
        e.preventDefault();	 
        var doIt = false;
        var acc_id = jQuery(this).attr("acc-id"); 
        doIt=confirm("Are you totally sure?");
		if(doIt){                    
            $.ajax({
                type: 'POST',
                url: ajaxurl,
                data: {"action": "wpmpg_delete_cpf",
                        "acc_id": acc_id},
                success: function(data){	
                    $("#acc-row-"+ acc_id).slideUp();
                }
            }); 
        }
        e.preventDefault();         
    });

    $(document).on("click", ".wpmpg-int-delete-acc-val", function(e) {
        e.preventDefault();	 
        var doIt = false;
        var acc_id = $(this).attr("acc-id"); 
        doIt=confirm("Are you totally sure?");
		if(doIt){                    
            $.ajax({
                type: 'POST',
                url: ajaxurl,
                data: {"action": "wpmpg_delete_cpf_value",
                        "acc_id": acc_id},
                success: function(data){	
                    $("#acc-row-"+ acc_id).slideUp();
                }
            }); 
        }
        e.preventDefault();         
    });      
    
    $(document).on("click", "#wpmsaic-download-from-url-btn", function() {          
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {"action": "wpmpg_download_url_file", 
                "link_to_download": $("#file_url").val()
            },                       
            success: function(data){
                var res = $.parseJSON(data);	             
                $("#file_uploaded").val(res.image);
                $("#msrm-imp-options").slideDown(400, function() {
                    if ($(this).css('display') === 'block') {
                        $("#wpmsaic-download-from-url-btn").addClass('on');
                    }
                });	
                $("#wmp-form").submit();                            
            }
        });      
    });    
});

function ms_build_links_array (){ 
    var progressbar = $( "#progressbar" );
    mmrunningstatus_mosaic =1;
    progressLabel = $( ".progress-label" );  

    $("#msearch_res").html('');
    $("#mm-title-status").html('Processing ... please wait.');
    $("#cancel-replace-process").html('CANCEL');    
    $("#wmp-btn-start-import-submit" ).prop( "disabled", true );
    $("#wmp-btn-back-to-step1" ).prop( "disabled", true );      

    hide_values_table('wpmosaic-import-tbl-body');
    hide_values_column('wms-val-col');

    progressbar.progressbar({
        value: false,
        change: function() {
          progressLabel.text( progressbar.progressbar( "value" ) + "%" );
        },
        complete: function() {
          progressLabel.html( "<span class='icon-check'>Complete</span>" );
        }
    });

    let selectedIDS = [];    
    $("#wpm-import-opt-bar").hide();  
    $("#wpm-progress-bar").slideDown(400);       
    let index = 0;
    let total_rows = $("#wp-total-rows ").val();
    let status_process = 1;
    let last_row = 0;
    
    const loop = setInterval(() => {
        console.log('Total Rows: ' + total_rows);       
        $.ajax({
            type: 'POST',
            url: ajaxurl,
            data: {"action": "wpmpg_start_process", 
                    "file_uploaded": $("#file_uploaded").val(),                  
                    "last": $("#last_row").val(),
                    "batch":$("#batch").val(),
                    "wp-custom-post-type":$("#wp-custom-post-type").val(),                    
                    },                       
                  success: function(data){
                    var res =jQuery.parseJSON(data);	
                    var from_row =  parseFloat($("#last_row").val()) + parseFloat($("#batch").val());
                    last_row = from_row;
                    $("#last_row").val(from_row);
                    var processed_rows_flag =  parseFloat($("#last_row").val() ) +  parseFloat($("#batch").val());                
                    var total_p =  parseFloat(res.cut_to) + parseFloat(res.last);
                    if(total_p>=total_rows){
                        total_p = total_rows;
                    }
                    $("#msrm-process-val").html(total_p);                   
                    mark_as_processed(total_p);                  
                    var percent_a = res.percent_a;
                    progressbar.progressbar( "value",  percent_a );                     
                    const postIds = res.postIDS;                                     

                    if( percent_a >= 100){
                        clearInterval(loop) ;
                        $("#msm-btn-steps-bar-steps").hide(); 
                        $("#wpm-import-results-block").show();                                           
                       //rebuild RM score
                       $('.wpmg-seoscore').slideDown(400); 
                       $('#rmcalculator').trigger('click'); 
                    }                         
                  }
        });       
        
    }, rtime);	
}

// Function to process a single post with rankMathEditor
function analyzePostWithEditor(postId, callback) {   
    $.ajax({
        url: ajaxurl,
        type: 'POST',
        data: {
            action: 'wpmpg_start_score_rebuild', // Custom PHP function
            post_id: postId,
        },
        success: function (response) {
            if (response.success) {
                console.log('Rank Math Plugin', rankMathEditor)
                const postData = response.data;
                if (typeof rankMathEditor !== 'undefined') {
                    rankMathEditor.data = {
                        ...rankMathEditor.data,
                        title: postData.title,
                        content: postData.content,
                        excerpt: postData.excerpt,
                    };
                    // Trigger analysis
                    rankMathEditor.refresh();
                    const seoScore = rankMathEditor.getScore();
                    const failedChecks = rankMathEditor.getFailed();
                    callback(null, {
                        postId: postId,
                        seoScore: seoScore,
                        failedChecks: failedChecks,
                    });
                } else {
                    callback('Rank Math Editor is not available');
                }
            } else {
                callback(`Failed to fetch data for Post ID ${postId}`);
            }
        },
        error: function () {
            callback(`AJAX request failed for Post ID ${postId}`);
        },
    });
}

// Function to process a batch of post IDs with a delay
function analyzePostsBatchWithDelay(postIds, delay = 1000) {
    const results = [];
    let currentIndex = 0;
    function processNextPost() {
        if (currentIndex >= postIds.length) {
            console.log('Batch Analysis Complete:', results);
            return;
        }
        const postId = postIds[currentIndex];
        console.log(`Processing Post ID: ${postId} (${currentIndex + 1}/${postIds.length})`);
        analyzePostWithEditor(postId, function (error, result) {
            if (error) {
                console.error(`Post ID: ${postId}:`, error);
            } else {
                console.log(`Post ID: ${postId} Results:`, result);
                results.push(result);
            }
            // Move to the next post after the delay
            currentIndex++;
            setTimeout(processNextPost, delay);
        });
    }
    // Start processing the first post
    processNextPost();
}    

function hide_values_table (field_values_clase){
    var checkbox_value = "";
    var i = 0;
    $("."+field_values_clase).each(function () {  
        $(this).addClass('wpm-hide_body-table'); 
    });   
}

function hide_values_column (field_values_clase){
    var checkbox_value = "";
    var i = 0;
    $("."+field_values_clase).each(function () {	   
        $(this).html('Pending ...'); 
    });   
}

function mark_as_processed (to_val){ 
    var i = 0;
    while (i <= to_val) {
        $("#wms-tbl-val-"+i).addClass('wpm-processed-row');   
        $("#wms-tbl-val-col-"+i).html('<span class="icon-check"><span class="text">Complete</span></span>');     
        i++;
    }  
}